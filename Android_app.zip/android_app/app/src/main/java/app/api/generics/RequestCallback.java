package app.api.generics;

public interface RequestCallback {

    void execute(ApiResponse response);
}
