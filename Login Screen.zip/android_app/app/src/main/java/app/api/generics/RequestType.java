package app.api.generics;

public enum RequestType {
    GET, POST;
}
