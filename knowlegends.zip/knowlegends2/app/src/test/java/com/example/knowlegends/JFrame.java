package com.example.knowlegends;

public class JFrame {
}
